﻿Public Class Test
    Private TestID As String
    'Containment/Aggregation
    Private Questions(10) As Question 'Arrays can't be declared with New
    Private NumberOfQuestions, MaxMarks As Integer
    Private Level As Char
    Private DateSet As Date

    Public Sub DesignTest(ByVal tID As String, ByVal tLevel As Char, ByVal tDate As Date)
        Dim qID, qText, qAnswser, qTopic As String, qMarks As Integer

        Me.TestID = tID
        Me.DateSet = tDate
        Me.Level = tLevel

        Console.Write("How many questions are there in Test " & Me.TestID & ": ")
        Me.NumberOfQuestions = Console.ReadLine
        While (Me.NumberOfQuestions < 0 Or Me.NumberOfQuestions > 10)
            Console.WriteLine("Wrong entry...")
            Console.Write("How many questions are there in Test " & Me.TestID & ": ")
            Me.NumberOfQuestions = Console.ReadLine
        End While

        For x As Integer = 1 To Me.NumberOfQuestions
            Console.Write("Enter question " & x & " ID: ") : qID = Console.ReadLine
            Console.Write("Enter question " & x & " topic: ") : qTopic = Console.ReadLine
            Console.Write("Enter question " & x & " marks: ") : qMarks = Console.ReadLine
            Console.Write("Enter question " & x & " text: ") : qText = Console.ReadLine
            Console.Write("Enter question " & x & " answer: ") : qAnswser = Console.ReadLine
            Questions(x) = New Question
            Questions(x).setQuestion(qID, qText, qAnswser, qMarks, qTopic)
        Next
    End Sub

    Public Sub PrintTest()
        Console.Clear()
        Console.WriteLine("Test ID: " & Me.TestID)
        Console.WriteLine("Test date: " & Me.DateSet)
        Console.WriteLine("Level" & Me.Level)

        Console.WriteLine("There are " & Me.NumberOfQuestions & " questions in Test " & Me.TestID & ". ")

        For x As Integer = 1 To Me.NumberOfQuestions
            Console.WriteLine("Q." & Questions(x).getQuestionID)
            Console.WriteLine("Marks: " & Questions(x).getMarks)
            Console.WriteLine("Text: " & Questions(x).getQuestion)
            Console.WriteLine()
        Next
        Console.ReadKey()
    End Sub

    Public Sub PrintAnswers()
        Console.Clear()
        Console.WriteLine("Test ID: " & Me.TestID)
        Console.WriteLine("Test date: " & Me.DateSet)
        Console.WriteLine("Level" & Me.Level)

        Console.WriteLine("There are " & Me.NumberOfQuestions & " questions in Test " & Me.TestID & ". ")

        For x As Integer = 1 To Me.NumberOfQuestions
            Console.WriteLine("Q." & Questions(x).getQuestionID)
            Console.WriteLine("Topic: " & Questions(x).getTopic)
            Console.WriteLine("Marks: " & Questions(x).getMarks)
            Console.WriteLine("Answer: " & Questions(x).getAnswser)
            Console.WriteLine()
        Next
        Console.ReadKey()
    End Sub
End Class
