﻿
Class Question
    Private QuestionID, QuestionText, Answser, Topic As String
    Private Marks As Integer

    Public Sub setQuestion(ByVal qID As String, ByVal qText As String, _
                   ByVal qAnswser As String, ByVal qMarks As Integer, _
                   ByVal qTopic As String)
        Me.QuestionID = qID
        Me.QuestionText = qText
        Me.Answser = qAnswser
        Me.Marks = qMarks
        Me.Topic = qTopic
    End Sub

    Public Function getQuestionID() As String
        Return Me.QuestionID
    End Function

    Public Function getQuestion() As String
        Return Me.QuestionText
    End Function

    Public Function getMarks() As Integer
        Return Me.Marks
    End Function

    Public Function getTopic() As String
        Return Me.Topic
    End Function

    Public Function getAnswser() As String
        Return Me.Answser
    End Function

End Class
