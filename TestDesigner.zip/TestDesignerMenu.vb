﻿Module TestMakingMenu

    Sub main()
        Dim TestID As String = ""
        Dim Level As Char = ""
        Dim DateSet As Date
        Dim alreadyDesigned As Boolean = False
        Dim MenuPick As Integer = 0

        Dim myTest As New Test

        Do
            Console.Clear()
            Console.WriteLine("1: Design test.")
            Console.WriteLine("2: Print test.")
            Console.WriteLine("3: Print test answers.")
            Console.WriteLine("0: To Exit program.")
            MenuPick = Console.ReadLine
            Select Case MenuPick
                Case 0 'This case to avoid Case Else when pressed 0 to Exit
                Case 1
                    If alreadyDesigned Then
                        Console.WriteLine("Test already designed...")
                        Console.ReadKey()
                    Else
                        Console.Write("Enter test ID: ") : TestID = Console.ReadLine
                        Console.Write("Enter test date: ") : DateSet = Console.ReadLine
                        Console.Write("Enter level: ") : Level = Console.ReadLine

                        myTest.DesignTest(TestID, Level, DateSet)
                        alreadyDesigned = True
                    End If
                Case 2 : myTest.PrintTest()
                Case 3 : myTest.PrintAnswers()
                Case Else
                    Console.WriteLine("Wrong Choice. Try gain or enter 0 to exit.")
                    Console.ReadKey()
            End Select
        Loop Until MenuPick = 0
    End Sub
End Module




